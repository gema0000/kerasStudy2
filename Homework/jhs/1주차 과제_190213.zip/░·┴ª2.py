#필요한 모듈 부르기 
import numpy as np
import pandas as pd
from keras.layers import Input,Dense,Activation,Concatenate
from keras.models import Sequential,Model
from sklearn.metrics import r2_score
from sklearn.metrics import mean_squared_error

def RMSE(y_test, y_predict):
    return np.sqrt(mean_squared_error(y_test, y_predict))

#train set build
x=np.array(range(1,11))
y=np.array(range(101,111))
x=x.reshape(-1,1)
y=y.reshape(-1,1)

#model build
first_input=Input(shape=(1,))
first_dense=Dense(1)(first_input)
second_input=Input(shape=(1,))
second_dense=Dense(1)(second_input)
merge=Concatenate()([first_dense,second_dense])
third_input=Input(shape=(2,))
third_dense=Dense(1)(merge)
model=Model(inputs=[first_input,second_input],outputs=third_dense)

#model compile
model.compile(optimizer='adamax',loss='mse',metrics=['mse'])

#show model structure
model.summary()

#model train
model.fit([x,y],y,epochs=100,batch_size=64)

#model predict
a=model.predict([x,y])

# get r2
r2_y_predict = r2_score(y, a)
print("R2 : ", r2_y_predict)

#get rmse
print("RMSE : ", RMSE(y, a))