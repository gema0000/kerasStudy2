# -*- coding: utf-8 -*-
"""
Created on Tue Jan 29 15:13:08 2019

@author: hose0
"""

from keras.models import Sequential
from keras.layers import LSTM, Dense,TimeDistributed,BatchNormalization
import numpy as np
import pandas as pd
import keras.backend as K
# 데이터 생성
x_train=np.array(range(11,10001))
y_train=np.array(range(12,10002))
x_train=pd.DataFrame(x_train)
y_train=pd.DataFrame(y_train)
#pandas shift 함수를 사용하여 시계열 데이터로 변환
for s in range(1, 5):
    x_train['shift_{}'.format(s)] = x_train[0].shift(-s)
    y_train['shift_{}'.format(s)] = y_train[0].shift(-s)
# NA값 제거
x_train=x_train.dropna()
y_train=y_train.dropna()
#LSTM input 형식으로 변환
x_train=np.array(x_train)
y_train=np.array(y_train)
x_train=x_train.reshape(-1,5,1)
y_train=y_train.reshape(-1,5,1)

#모델 생성
K.clear_session()
model=Sequential()
model.add(LSTM(10,input_shape=(5,1),return_sequences=True))
model.add(TimeDistributed(Dense(1)))
model.compile(loss='mean_squared_error',optimizer='adam')

model.fit(x_train,y_train,epochs=50,batch_size=32)
print(model.summary())