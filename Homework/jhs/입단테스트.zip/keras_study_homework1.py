import numpy as np
from keras.models import Sequential
from keras.layers import Dense, Activation
from keras.models import load_model

#학습 데이터 셋과 테스틑 셋을 만들어 줍니다.
x_train=np.array(range(11,20000))
y_train=np.array(range(11,20000))
x_test=np.array(range(1,11))
y_test=np.array(range(1,11))


#숫차 모델로 선언하고, 신경망 1층을 추가합니다.
model=Sequential()
model.add(Dense(1, input_dim=1))

# 모델을 Optimzer와 loss 함수를 지정해 주고 컴파일 합니다.
model.compile(optimizer='adamax', loss='mse')

# 모델 학습시킵니다.
hist = model.fit(x_train, y_train, epochs=50, batch_size=64)
#모델에서 weights를 얻습니다.
w, b = model.get_weights()
print("w: {0}, b: {1}".format(w,b))

# 테스트 셋을 예측해 봅니다.
a=model.predict(x_test)
print(a)

'''
모델을 저장하고자 하면 다음의 코드를 입력해줍니다.
model.save('keras_model1.h5')

'''

# RMSE 구하기
y_pred=model.predict(x_test)
y_pred=y_pred.flatten()
rmse=np.sqrt(np.mean((y_pred-y_test)**2))
'''
R^2값을 구하기 위해 sst,ssr을 구합니다.
'''
y_mean=np.mean(y_test)
ssr=np.sum((y_pred-y_mean)**2)
sst=np.sum((y_test-y_mean)**2)
r_2=ssr/sst
